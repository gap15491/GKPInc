npm run doabunchofstuff
